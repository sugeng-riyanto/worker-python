from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import zipfile
import re

ROOT = Path(__file__).resolve().parent
QUARTO = shutil.which('quarto')
if not QUARTO:
    sys.exit('Install Quarto CLI from https://quarto.org/docs/get-started/ and reopen the terminal.')


def render(*args, cwd=ROOT, stdout=None):
    subprocess.run([QUARTO, *args], cwd=cwd, stdout=stdout, check=True)


def make_word_reference():
    target = ROOT / 'b5-reference.docx'
    with tempfile.TemporaryDirectory() as temporary:
        default = Path(temporary) / 'default.docx'
        with default.open('wb') as output:
            render('pandoc', '--print-default-data-file=reference.docx', stdout=output)
        with zipfile.ZipFile(default) as source, zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as result:
            for member in source.infolist():
                data = source.read(member)
                if member.filename == 'word/document.xml':
                    xml = data.decode('utf-8')
                    xml, size = re.subn(r'<w:pgSz\b[^>]*/>', '<w:pgSz w:w="9978" w:h="14173"/>', xml)
                    xml, margins = re.subn(r'<w:pgMar\b[^>]*/>', '<w:pgMar w:top="1020" w:right="794" w:bottom="1020" w:left="1134" w:header="450" w:footer="450" w:gutter="0"/>', xml)
                    additions = ''
                    if not size:
                        additions += '<w:pgSz w:w="9978" w:h="14173"/>'
                    if not margins:
                        additions += '<w:pgMar w:top="1020" w:right="794" w:bottom="1020" w:left="1134" w:header="450" w:footer="450" w:gutter="0"/>'
                    if additions:
                        xml, count = re.subn(r'</w:sectPr>', additions + '</w:sectPr>', xml, count=1)
                        if not count:
                            raise RuntimeError('Could not apply B5 page geometry to reference.docx')
                    data = xml.encode('utf-8')
                if member.filename == 'word/settings.xml':
                    xml = data.decode('utf-8')
                    if '<w:mirrorMargins' not in xml:
                        xml = xml.replace('</w:settings>', '<w:mirrorMargins/></w:settings>')
                    data = xml.encode('utf-8')
                result.writestr(member, data)


formats = {'PDF':'typst','DOCX':'docx','HTML':'html','EPUB':'epub','FLIPBOOK':'flipbook'}
selection = (sys.argv[1] if len(sys.argv) > 1 else (ROOT / 'format.txt').read_text().strip()).upper()
if selection != 'ALL' and selection not in formats:
    sys.exit('Choose ALL, PDF, DOCX, HTML, EPUB, or FLIPBOOK.')
ordered = list(formats) if selection == 'ALL' else [selection]
try:
    for name in ordered:
        if name == 'DOCX':
            make_word_reference()
        format_name = formats[name]
        if name == 'FLIPBOOK':
            render('render', 'flipbook.qmd', '--to', 'revealjs', cwd=ROOT / 'flipbook')
            (ROOT / '_output').mkdir(exist_ok=True)
            shutil.copy2(ROOT / 'flipbook' / 'flipbook.html', ROOT / '_output' / 'flipbook.html')
        else:
            render('render', '--to', format_name)
            shutil.copytree(ROOT / '_render', ROOT / '_output', dirs_exist_ok=True)
except (subprocess.CalledProcessError, OSError, RuntimeError) as error:
    sys.exit(f'Render failed: {error}')
print(f'Output: {ROOT / "_output"}')
