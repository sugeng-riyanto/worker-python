#import "@preview/orange-book:0.7.1": book, part, chapter, appendices

#show: book.with(
  title: [$title$],
  author: "$for(by-author)$$it.name.literal$$sep$, $endfor$",
  paper-size: "iso-b5",
  margin: (inside: 20mm, outside: 14mm, top: 18mm, bottom: 18mm),
  main-color: rgb("#0F2942"),
  font-size: 10.2pt,
  outline-depth: 3,
  lang: "$lang$",
)
