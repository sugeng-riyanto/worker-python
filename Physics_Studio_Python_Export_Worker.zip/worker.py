"""Private Quarto rendering worker with expiring, signed output links."""
from concurrent.futures import ThreadPoolExecutor
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path, PurePosixPath
import hashlib
import hmac
import io
import json
import mimetypes
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
from urllib.parse import urlsplit
from uuid import uuid4
from zipfile import ZipFile, BadZipFile

ROOT = Path(__file__).resolve().parent
TOKEN = os.environ.get('QUARTO_WORKER_TOKEN', '')
if len(TOKEN) < 32:
    raise SystemExit('Set QUARTO_WORKER_TOKEN to a random value of at least 32 characters.')
BIND = os.environ.get('QUARTO_WORKER_BIND', '127.0.0.1')
PORT = int(os.environ.get('QUARTO_WORKER_PORT', 8765))
TTL = 1800
LIMIT = 12 * 1024 * 1024
FORMATS = {'PDF': '.pdf', 'DOCX': '.docx', 'HTML': '.html', 'EPUB': '.epub', 'FLIPBOOK': '.html'}
ALLOWED = re.compile(r'(?:bab-\d+\.qmd|index\.qmd|flipbook/flipbook\.qmd)\Z')
RISKY = re.compile(r'\{\{[<%]|(?m:^\s*(?:`{3,}|~{3,})\s*\{)|\]\(\s*(?:file:|/|\.\./)|<\s*(?:script|iframe|object|embed)\b', re.I)
LOCK = threading.Lock()
POOL = ThreadPoolExecutor(max_workers=1)
JOBS = {}


def signed(job, filename, expires):
    return hmac.new(TOKEN.encode(), f'{job}/{filename}/{expires}'.encode(), hashlib.sha256).hexdigest()


def stage_source(raw, work):
    title = "Physics Textbook Studio"
    with ZipFile(io.BytesIO(raw)) as archive:
        if '_quarto.yml' in archive.namelist() and archive.getinfo('_quarto.yml').file_size < 32000:
            settings = archive.read('_quarto.yml').decode('utf-8')
            match = re.search(r'^  title: ("[^\n]{1,600}")$', settings, re.M)
            if match:
                parsed = json.loads(match[1])
                if isinstance(parsed,str) and len(parsed) <= 200:
                    title = ' '.join(parsed.split())
        entries = [m for m in archive.infolist() if ALLOWED.fullmatch(m.filename)]
        names = [m.filename for m in entries]
        chapters = sorted(name for name in names if name.startswith('bab-'))
        if not 1 <= len(chapters) <= 80 or len(set(names)) != len(names) or not {'index.qmd', 'flipbook/flipbook.qmd'} <= set(names):
            raise ValueError('Invalid chapter archive')
        if sum(m.file_size for m in entries) > LIMIT:
            raise ValueError('Source too large')
        for entry in entries:
            text = archive.read(entry).decode('utf-8')
            if RISKY.search(text):
                raise ValueError('Active source directives are not supported')
            if entry.filename.startswith('bab-') and text.lstrip().startswith('---'):
                raise ValueError('Chapter front matter is not supported')
            if entry.filename.startswith('flipbook/'):
                text = text.split('\n---\n', 1)[-1]
                text = '---\nformat:\n  revealjs:\n    embed-resources: true\n    slide-level: 2\n    transition: slide\n    scrollable: true\n    slide-number: c/t\n---\n'+text
            path = work / entry.filename
            path.parent.mkdir(exist_ok=True)
            path.write_text(text, encoding='utf-8')
    config = '''project:
  type: book
  output-dir: _render
  render:
    - "*.qmd"
book:
  title: ''' + json.dumps(title,ensure_ascii=False) + '''
  author: "Academic Physics Publishing Team"
  output-file: physics
  chapters:
    - index.qmd
''' + ''.join(f'    - {chapter}\n' for chapter in chapters) + '''lang: id
execute:
  enabled: false
toc: true
format:
  typst:
    papersize: iso-b5
    template-partials: [typst-show.typ]
  docx:
    reference-doc: b5-reference.docx
  html:
    theme: cosmo
  epub: default
'''
    (work/'_quarto.yml').write_text(config, encoding='utf-8')
    (work/'flipbook'/'_quarto.yml').write_text('project:\n  type: default\nexecute:\n  enabled: false\n', encoding='utf-8')
    shutil.copy2(ROOT/'typst-show.typ', work/'typst-show.typ')
    shutil.copy2(ROOT/'render.py', work/'render.py')


def run(job, format_name):
    row = JOBS[job]
    env = {k:v for k,v in os.environ.items() if k in {'PATH','HOME','USERPROFILE','SYSTEMROOT','WINDIR','TMP','TEMP','LANG','LC_ALL','QUARTO_PATH','APPDATA','LOCALAPPDATA','PATHEXT','ProgramFiles'}}
    try:
        subprocess.run([sys.executable, 'render.py', format_name], cwd=row['dir'], env=env,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True, timeout=240)
        output = 'index.html' if format_name=='HTML' else 'flipbook.html' if format_name=='FLIPBOOK' else 'physics'+FORMATS[format_name]
        if not (row['dir']/'_output'/output).is_file():
            raise RuntimeError('Missing output')
        with LOCK:
            row.update(state='done', output=output, expires=int(time.time())+TTL)
    except (OSError, subprocess.SubprocessError, RuntimeError):
        with LOCK:
            row.update(state='failed', expires=int(time.time())+TTL)


def prune():
    expired = [job for job,row in JOBS.items() if row['state']!='queued' and row['expires']<time.time()]
    for job in expired:
        shutil.rmtree(JOBS.pop(job)['dir'], ignore_errors=True)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass  # Signed links and authoring paths stay out of access logs.

    def json(self, status, data):
        body=json.dumps(data).encode()
        self.send_response(status)
        self.send_header('Content-Type','application/json')
        self.send_header('Cache-Control','no-store')
        self.send_header('Content-Length',str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def authorized(self):
        return hmac.compare_digest(self.headers.get('Authorization',''), 'Bearer '+TOKEN)

    def do_POST(self):
        match=re.fullmatch(r'/jobs/(PDF|DOCX|HTML|EPUB|FLIPBOOK)',urlsplit(self.path).path)
        if not self.authorized():
            return self.json(401,{'error':'Unauthorized'})
        if not match:
            return self.json(404,{'error':'Unknown format'})
        try:
            size=int(self.headers.get('Content-Length','0'))
        except ValueError:
            size=0
        if not 0<size<=LIMIT:
            return self.json(413,{'error':'Invalid archive size'})
        raw=self.rfile.read(size)
        with LOCK:
            prune()
            if len(JOBS)>=20 or sum(row['state']=='queued' for row in JOBS.values())>=3:
                return self.json(429,{'error':'Renderer busy'})
            job=uuid4().hex
            work=Path(tempfile.mkdtemp(prefix='physics-quarto-'))
            try:
                stage_source(raw,work)
            except (ValueError, OSError, BadZipFile):
                shutil.rmtree(work,ignore_errors=True)
                return self.json(400,{'error':'Invalid Quarto archive'})
            JOBS[job]={'state':'queued','dir':work}
        POOL.submit(run,job,match[1])
        return self.json(202,{'job':job})

    def do_GET(self):
        path=urlsplit(self.path).path
        match=re.fullmatch(r'/jobs/([a-f0-9]{32})',path)
        if match:
            if not self.authorized():
                return self.json(401,{'error':'Unauthorized'})
            with LOCK:
                prune()
                row=JOBS.get(match[1])
                if not row:
                    return self.json(404,{'error':'Unknown job'})
                payload={'state':row['state']}
                if row['state']=='done':
                    expires=row['expires']
                    sig=signed(match[1],row['output'],expires)
                    payload['path']=f'/files/{match[1]}/{expires}/{sig}/{row["output"]}'
            return self.json(200,payload)
        link=re.fullmatch(r'/files/([a-f0-9]{32})/(\d{1,12})/([a-f0-9]{64})/([a-zA-Z0-9_.\-/]+)',path)
        if not link:
            return self.json(404,{'error':'Unknown path'})
        job,expires,sig,name=link.groups()
        relative=PurePosixPath(name)
        if relative.is_absolute() or '..' in relative.parts or int(expires)<time.time():
            return self.json(404,{'error':'Invalid or expired link'})
        with LOCK:
            row=JOBS.get(job)
            if not row or row['state']!='done' or not hmac.compare_digest(signed(job,row['output'],int(expires)),sig):
                return self.json(404,{'error':'Invalid or expired link'})
            root=(row['dir']/'_output').resolve()
            output=(root/relative).resolve()
            if not output.is_relative_to(root) or not output.is_file():
                return self.json(404,{'error':'File unavailable'})
            payload=output.read_bytes()
        content_type=mimetypes.guess_type(output.name)[0] or 'application/octet-stream'
        self.send_response(200)
        self.send_header('Content-Type',content_type)
        self.send_header('Content-Length',str(len(payload)))
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('Cache-Control','private, no-store')
        self.send_header('Referrer-Policy','no-referrer')
        if output.suffix in {'.docx','.epub'}:
            self.send_header('Content-Disposition',f'attachment; filename="{output.name}"')
        self.end_headers()
        self.wfile.write(payload)


if __name__=='__main__':
    ThreadingHTTPServer((BIND,PORT),Handler).serve_forever()
