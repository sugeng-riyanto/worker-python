# Physics Textbook Studio · Python render worker

Requires Python 3.10 or newer and Quarto CLI 1.11.9 on PATH.
Sign in as a dedicated, unprivileged OS user. Run only trusted Studio authoring
bundles in a dedicated environment without access to unrelated private files.
A first Typst render may fetch Quarto/Typst packages.

1. Generate an independent random secret (e.g. `python -c "import secrets; print(secrets.token_urlsafe(48))"`).
2. Set the worker environment variable `QUARTO_WORKER_TOKEN` to that value.
3. Run `python worker.py`. The default bind is 127.0.0.1:8765.
4. Put the worker behind an HTTPS reverse proxy on a dedicated hostname.
   Keep the process bound to loopback. Set a 12 MiB request limit for ZIPs,
   disable sensitive URL logging, and configure relaying of Authorization.
   Treat the result origin as isolated from other organization applications.
5. In Apps Script Script Properties set `QUARTO_WORKER_URL` to the HTTPS
   origin (no path), and `QUARTO_WORKER_TOKEN` to the same worker secret.
6. Reload the Studio. Click a specific format from a saved chapter or book.
   PDF, HTML and Flipbook open in the result tab. Browsers normally download
   DOCX and EPUB when navigating to those results.

Results are temporary and the signed URL expires after approximately 30 minutes.
The ZIP flow remains available under "Semua format".
The worker reconstructs Quarto project settings and runs its bundled renderer.
